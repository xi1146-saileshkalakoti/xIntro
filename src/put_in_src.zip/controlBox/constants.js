export const screens = [
  "#splash",
  "#home",
  "#xebiaGroup",
  "#bornInNetherlands",
  "#organisationStructure",
  "#organizationMatrix",
  "#cultureOfInovation",
  "#toolsWeUse",
  "#leavePolicy",
  "#holidayCalendar",
  "#longService",
  "#rewardsAndRecognition",
  "#probationPeriod",
  "#performanceAppraisal",
  "#funAtXebia",
  "#xebiaCares",
  "#thingsToRemember",
  "#thankyou",
  "#feelingBored"
];
export const DEFAULT_SCREEN_INDEX = 0;
export const DEFAULT_SCREEN_TO_SHOW = screens[DEFAULT_SCREEN_INDEX];
export const SHOW_NAV_FROM_INDEX = 0;
