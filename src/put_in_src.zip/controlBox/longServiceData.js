export const longServiceData = {
  longServiceData: {
    headers: [
      "Category",
      "Hattrick Hero",
      "Fabulous Five",
      "Terrific Ten",
      "Flawless Fifteen"
    ],
    body: [
      [
        "No of years",
        "3 years of service",
        "5 years of service",
        "10 years of service",
        "15 years of service"
      ],
      [
        "Gift 1",
        "Certificate signed by CEO",
        "Certificate signed by CEO",
        "Certificate signed by CEO",
        "Certificate signed by CEO"
      ],
      [
        "Gift 2",
        "Gold Coin weight 3 gm. With Xebia imprinted",
        "Gold Coin weight 5 gm. With Xebia imprinted",
        "Gold Coin weight 10 gm. With Xebia imprinted",
        "Gold Coin weight 15 gm. With Xebia imprinted"
      ],
      [
        "Gift 3",
        "15 days of Basic Pay (*For Xebia US: 50,000/- INR equivalent)",
        "One month of Basic Pay (*For Xebia US: 80,000/- INR equivalent)",
        "One month of Basic Pay (*For Xebia US: 100,000/- INR equivalent)",
        "One month of Basic Pay (*For Xebia US: 150,000/- INR equivalent)"
      ],
      [
        "Gift 4",
        "Experience worth INR 10,000/- from **Assorted Benefits Basket",
        "Experience worth INR 30,000/- from **Assorted Benefits Basket",
        "Experience worth INR 50,000/- from **Assorted Benefits Basket",
        "Experience worth INR 100,000/- from **Assorted Benefits Basket"
      ]
    ]
  }
};
